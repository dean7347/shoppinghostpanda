package com.studyolle.studyolle.settings.form;


import com.studyolle.studyolle.domain.Account;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.modelmapper.ModelMapper;

@Data
public class Notifications {
    private boolean studyCreatedByEmail;
    private boolean studyCreatedByWeb;
    private boolean studyEnrollmentResultByWeb;
    private boolean studyEnrollmentResultByEmail;
    private boolean studyUpdatedByEmail;
    private boolean studyUpdatedByWeb;

//    public Notifications(Account account) {
//
//
//        this.studyCreatedByEmail = studyCreatedByEmail;
//        this.studyCreatedByWeb = studyCreatedByWeb;
//        this.studyEnrollmentResultByWeb = studyEnrollmentResultByWeb;
//        this.studyEnrollmentResultByEmail = studyEnrollmentResultByEmail;
//        this.studyUpdatedByEmail = studyUpdatedByEmail;
//        this.studyUpdatedByWeb = studyUpdatedByWeb;
//    }
}
