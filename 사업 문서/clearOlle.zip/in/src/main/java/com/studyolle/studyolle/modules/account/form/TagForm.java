package com.studyolle.studyolle.modules.account.form;

import lombok.Data;

@Data
public class TagForm {

    private String tagTitle;
}
