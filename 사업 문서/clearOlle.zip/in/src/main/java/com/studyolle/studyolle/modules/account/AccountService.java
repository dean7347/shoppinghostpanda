package com.studyolle.studyolle.modules.account;


import com.studyolle.studyolle.infra.config.AppProperties;
import com.studyolle.studyolle.modules.tag.Tag;
import com.studyolle.studyolle.modules.zone.Zone;
import com.studyolle.studyolle.infra.mail.EmailMessage;
import com.studyolle.studyolle.infra.mail.EmailService;
import com.studyolle.studyolle.modules.account.form.Notifications;
import com.studyolle.studyolle.modules.account.form.Profile;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Slf4j
//트랜잭션 안의 범위명시해줘야한다
@Transactional
@Service
@RequiredArgsConstructor
public class AccountService implements UserDetailsService {


    @Autowired
    private AccountRepository accountRepository;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;
    private final ModelMapper modelMapper;
    private final TemplateEngine templateEngine;
    private final AppProperties appProperties;


    public Account processNewAccount(SignUpForm signUpForm) {
        Account newAccount = saveNewAccount(signUpForm);
        sendSignUpConfirmEmail(newAccount);
        return newAccount;
    }

    private Account saveNewAccount(@Valid SignUpForm signUpForm) {
        signUpForm.setPassword(passwordEncoder.encode(signUpForm.getPassword()));
        Account account = modelMapper.map(signUpForm, Account.class);
        account.generateEmailCheckToken();
        return accountRepository.save(account);
    }

    public void sendSignUpConfirmEmail(Account newAccount) {
        //모델이라고 생각
        Context context = new Context();
        context.setVariable("link", "/check-email-token?token=" + newAccount.getEmailCheckToken()
                + "&email=" + newAccount.getEmail());
        context.setVariable("nickname", newAccount.getNickname());
        context.setVariable("linkName", "이메일 인증하기");
        context.setVariable("message", "스터디 올래 서비스를 사용하려면 링크를 클릭하세요");
        //밸류는 유동적이니까 프로퍼티에 app.host=http://localhost:8080
        //개발환경이나 운영환경에서는 도메인으로 셋팅한다
        context.setVariable("host", appProperties.getHost());
        String message = templateEngine.process("mail/simple-link", context);


        EmailMessage emailMessage = EmailMessage.builder()
                .to(newAccount.getEmail())
                .subject("스터디 올래 회원가입 인증")
                .message(message)
                .build();
        emailService.sendEmail(emailMessage);

//        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
//        //핼퍼가 감쌀 마임메시지 마임메세지인지 여부 (첨부파일보낼려면 트루), 캐릭터셋
//        MimeMessageHelper mimeMessageHelper = null;
//        try {
//            mimeMessageHelper = new MimeMessageHelper(mimeMessage, false,"UTF-8");
//            mimeMessageHelper.setTo(newAccount.getEmail());
//            mimeMessageHelper.setText("/check-email-token?token=" + newAccount.getEmailCheckToken() +
//                    "&email=" + newAccount.getEmail(),false);
//            javaMailSender.send(mimeMessage);
//        } catch (MessagingException e) {
//            log.error("failed to send email",e);
//        }
//
//        SimpleMailMessage mailMessage = new SimpleMailMessage();
//        mailMessage.setTo(newAccount.getEmail());
//        mailMessage.setSubject("스터디 올래, 회원 가입 인증");
//        mailMessage.setText("/check-email-token?token=" + newAccount.getEmailCheckToken() +
//                "&email=" + newAccount.getEmail());
//        javaMailSender.send(mailMessage);
    }

    public void login(Account account) {
        //인코딩한 password만 접근할 수 있기때문에 이방법을 사용
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
                new UserAccount(account),
                account.getPassword(),
                List.of(new SimpleGrantedAuthority("ROLE_USER")));

        SecurityContextHolder.getContext().setAuthentication(token);


//        //정석적으론 폼인증할떄 쓰인다
//        UsernamePasswordAuthenticationToken.token = new UsernamePasswordAuthenticationToken(
//                username, password);
//        AuthenticationManager authentication = authenticationManager.authenticate(token);
//        SecurityContext context = SecurityContextHolder.getContext();
//        context.setAuthentication(authentication);
    }

    //데이터 변경이아닌 조회는 리드온리
    @Transactional(readOnly = true)
    @Override
    public UserDetails loadUserByUsername(String emailOrNickName) throws UsernameNotFoundException {
        Account account = accountRepository.findByEmail(emailOrNickName);
        if (account == null) {
            account = accountRepository.findByNickname(emailOrNickName);
        }
        if (account == null) {
            throw new UsernameNotFoundException(emailOrNickName);
        }
        return new UserAccount(account);
    }


    public void completeSignUp(Account account) {
        account.completeSignUp();
        login(account);
    }

    public void updateProfile(Account account, Profile profile) {
        modelMapper.map(profile, account);

//        account.setUrl(profile.getUrl());
//        account.setOccupation(profile.getOccupation());
//        account.setLocation(profile.getLocation());
//        account.setBio(profile.getBio());
//
//        account.setProfileImage(profile.getProfileImage());
        //detached상태의 객체 싱크를맞춰주자
        accountRepository.save(account);

    }

    public void updatePassword(Account account, String newPassword) {
        account.setPassword(passwordEncoder.encode(newPassword));
        accountRepository.save(account);
    }

    public void updateNotifications(Account account, Notifications notifications) {
        //함정! 매퍼는 패턴과 프로퍼티설정이 필요함
        //기본설정은 모든 토크나이저와 패턴이 다 적용되어있다
        modelMapper.map(notifications, account);

//        account.setStudyCreatedByEmail(notifications.isStudyCreatedByWeb());
//        account.setStudyCreatedByWeb(notifications.isStudyCreatedByWeb());
//        account.setStudyEnrollmentResultByEmail(notifications.isStudyEnrollmentResultByEmail());
//        account.setStudyEnrollmentResultByWeb(notifications.isStudyEnrollmentResultByWeb());
//        account.setStudyUpdatedByWeb(notifications.isStudyUpdatedByWeb());
//        account.setStudyUpdatedByEmail(notifications.isStudyUpdatedByEmail());
        accountRepository.save(account);
    }

    public void updateNickname(Account account, String nickname) {

        account.setNickname(nickname);
        //디테치드 객ㅊ페 디비반영
        accountRepository.save(account);
        login(account);

    }

    public void sendLoginLink(Account account) {
        Context context = new Context();
        context.setVariable("link", "/check-email-token?token=" + account.getEmailCheckToken()
                + "&email=" + account.getEmail());
        context.setVariable("nickname", account.getNickname());
        context.setVariable("linkName", "이메일로 로그인하기");
        context.setVariable("message", "로그인 하려면 아래 링크를 클릭하세요");
        //밸류는 유동적이니까 프로퍼티에 app.host=http://localhost:8080
        //개발환경이나 운영환경에서는 도메인으로 셋팅한다
        context.setVariable("host", appProperties.getHost());
        String message = templateEngine.process("mail/simple-link", context);



        EmailMessage emailMessage = EmailMessage.builder()
                .to(account.getEmail())
                .subject("스터디 올래 회원가입 인증")
                .message("/check-email-token?token=" + account.getEmailCheckToken() +
                        "&email=" + account.getEmail())
                .build();
        emailService.sendEmail(emailMessage);

//        account.generateEmailCheckToken();
//        SimpleMailMessage mailMessage = new SimpleMailMessage();
//        mailMessage.setTo(account.getEmail());
//        mailMessage.setSubject("스터디 올래 로그인 링크");
//        mailMessage.setText("/login-by-email?token=" + account.getEmailCheckToken() + "&email=" + account.getEmail());
//        javaMailSender.send(mailMessage);
    }

    public void addTag(Account account, Tag tag) {
        //이거로딩으로 무조건읽어오고
        Optional<Account> byId = accountRepository.findById(account.getId());
        byId.ifPresent(a -> a.getTags().add(tag));
        //getone은 레이지 로딩이다 필요한순간에만 읽어옴옴
        //accountRepositroy.getOne()
    }

    public Set<Tag> getTags(Account account) {

        Optional<Account> byId = accountRepository.findById(account.getId());
        return byId.orElseThrow().getTags();
    }

    public void removeTag(Account account, Tag tag) {
        Optional<Account> byId = accountRepository.findById(account.getId());
        byId.ifPresent(a->a.getTags().remove(tag));
    }

    public Set<Zone> getZones(Account account) {
        Optional<Account> byId = accountRepository.findById(account.getId());

        return byId.orElseThrow().getZones();
    }


    public void addZone(Account account, Zone zone) {
        Optional<Account> byId = accountRepository.findById(account.getId());
        byId.ifPresent(a->a.getZones().add(zone));
    }

    public void removeZone(Account account,Zone zone) {
        Optional<Account> byId = accountRepository.findById(account.getId());
        byId.ifPresent(a->a.getZones().remove(zone));
    }

    public Account getAccount(String nickname) {
        Account byNickname = accountRepository.findByNickname(nickname);
        if (nickname == null) {
            throw new IllegalArgumentException(nickname + "에 해당하는 사용자가 없습니다");
        }
        return byNickname;
    }
}

