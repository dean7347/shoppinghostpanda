package com.studyolle.studyolle.infra.mail;

public interface EmailService {

    void sendEmail(EmailMessage emailMessage);
}
