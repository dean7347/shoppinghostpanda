package com.studyolle.studyolle.modules.event;


import com.studyolle.studyolle.modules.account.Account;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

@NamedEntityGraph(
        name = "Enrollment.withEventAndStudy",
        attributeNodes = {
                @NamedAttributeNode(value = "event", subgraph = "study")
        },
        subgraphs = @NamedSubgraph(name = "study", attributeNodes = @NamedAttributeNode("study"))
)
@Entity
@Getter @Setter @EqualsAndHashCode(of = "id")

public class Enrollment {

    @Id @GeneratedValue
    private Long id;

    //이벤트에는 여러개의 참가 신청이 있을수 있다
    //하나의 enrollment는 하나의 이벤트에 속해있지만
    //참가신청 하나는 특정 이벤트 하나에 매핑이된다 그래서 to one이다
    @ManyToOne
    private Event event;

    @ManyToOne
    private Account account;

    private LocalDateTime enrolledAt;

    private boolean accepted;

    private boolean attended;


}
