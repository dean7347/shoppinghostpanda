package com.studyolle.studyolle.modules.event;

public enum EventType {

    FCFS, CONFIRMATIVE
}
