package com.studyolle.studyolle.modules.study;

import com.querydsl.core.QueryResults;
import com.querydsl.jpa.JPQLQuery;
import com.studyolle.studyolle.modules.account.QAccount;
import com.studyolle.studyolle.modules.tag.QTag;
import com.studyolle.studyolle.modules.tag.Tag;
import com.studyolle.studyolle.modules.zone.QZone;
import com.studyolle.studyolle.modules.zone.Zone;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.support.QuerydslRepositorySupport;

import java.util.List;
import java.util.Set;

public class StudyRepositoryExtensionImpl extends QuerydslRepositorySupport implements StudyRepositoryExtension {
    //인스턴스 생성시 상위 클래스의 생성자를 호출
    //기본생성자 밖에없으니까 상위클래스의 기본생성자 호출
    //상위클래스의 기본생성자가 없으니까 에러가나서
    //만들어준것 상위클래스의 디폴트생성자가 있었으면 에락 ㅏ발생하지않음
    //파라미터 하나받는 이런생성자 밖에 없기때문에에
//   public StudyRepositoryExtensionimpl(Class<?> domainClass) {
//        super(domainClass);
//    }
    //부모생성자에 넘겨준 파라미터를 가지고있는 자식클래스의 생성자를 만들어준다
    //하지만 우리는 어떤도메인타입을 다루는지 알고있어서 넘겨기만 하면된다

    public StudyRepositoryExtensionImpl() {
        super(Study.class);
    }
    @Override
    public Page<Study> findByKeyword(String keyword, Pageable pageable) {

        QStudy study = QStudy.study;
        JPQLQuery<Study> query = from(study).where(study.published.isTrue()
                .and(study.title.containsIgnoreCase(keyword))
                .or(study.tags.any().title.containsIgnoreCase(keyword))
                .or(study.zones.any().localNameOfCity.containsIgnoreCase(keyword)))
                //패치조인은 조인한데이터 가져옴
                .leftJoin(study.tags, QTag.tag).fetchJoin()
                .leftJoin(study.zones, QZone.zone).fetchJoin()
                .leftJoin(study.members, QAccount.account).fetchJoin()
                .distinct();

        JPQLQuery<Study> pageableQuery = getQuerydsl().applyPagination(pageable, query);
        QueryResults<Study> fetchResults = pageableQuery.fetchResults();
        return new PageImpl<>(fetchResults.getResults(), pageable, fetchResults.getTotal());

    }

    @Override
    public List<Study> findByAccount(Set<Tag> tags, Set<Zone> zones) {
        QStudy study = QStudy.study;
        JPQLQuery<Study> query = from(study).where(study.published.isTrue()
                .and(study.closed.isFalse())
                .and(study.tags.any().in(tags))
                .and(study.zones.any().in(zones)))
                .leftJoin(study.tags, QTag.tag).fetchJoin()
                .leftJoin(study.zones, QZone.zone).fetchJoin()
                .orderBy(study.publishedDateTime.desc())
                .distinct()
                .limit(9);
        return query.fetch();
    }
}
