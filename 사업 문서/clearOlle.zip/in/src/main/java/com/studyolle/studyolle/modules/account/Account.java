package com.studyolle.studyolle.modules.account;

import com.studyolle.studyolle.modules.study.Study;
import com.studyolle.studyolle.modules.tag.Tag;
import com.studyolle.studyolle.modules.zone.Zone;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Getter
@Setter
@EqualsAndHashCode(of= "id")
@Builder @AllArgsConstructor @NoArgsConstructor
public class Account {
    @Id @GeneratedValue
    private Long id;

    //두개있으면 안된다 유니크
    @Column(unique = true)
    private String email;

    @Column(unique = true)
    private String nickname;

    private String password;

    //인증여부
    private boolean emailVerified;
    // 토큰값
    private String emailCheckToken;

    private LocalDateTime joinedAt;
    private LocalDateTime emailCheckTokenGeneratedAt;

    private String bio;
    private String url;
    private String occupation;
    private String location; //varchar(255)
    //텍스트 타입 매칭
    //로딩시 같이 가져와야하기때문에
    @Lob @Basic(fetch = FetchType.EAGER)
    private String profileImage;

    private boolean studyCreatedByEmail;
    private boolean studyCreatedByWeb= true;
    private boolean studyEnrollmentResultByWeb= true;
    private boolean studyEnrollmentResultByEmail;
    private boolean studyUpdatedByEmail;
    private boolean studyUpdatedByWeb= true;


    @ManyToMany
    private Set<Tag> tags= new HashSet<>();

    @ManyToMany
    private Set<Zone> zones = new HashSet<>();


    public void generateEmailCheckToken() {
        this.emailCheckToken = UUID.randomUUID().toString();
        this.emailCheckTokenGeneratedAt = LocalDateTime.now();
    }

    public void completeSignUp() {
        this.emailVerified=true;
        this.joinedAt = LocalDateTime.now();


    }

    public boolean isVaildToken(String token) {
        return this.emailCheckToken.equals(token);
    }

    public boolean canSendConfirmEmail() {
        return this.emailCheckTokenGeneratedAt.isBefore(LocalDateTime.now().minusHours(1));
    }



}
